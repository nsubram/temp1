import { Component } from '@angular/core';
import { UIConfigurableModel } from '../base/models/ui-configurable.model';
import { ReusableMethodsModel } from '../base/models/reusable-methods.model';
import { WebSocketService } from '../base/services/websocket.service';
import { ApiService } from '../base/services/api.service';
import { SearchParamsModel } from '../base/models/search-params.model';
import { StaticData } from '../base/helpers/static-data';
import { ImageHelper } from '../base/helpers/image-helper';
import { RestService } from '../base/services/base/rest.service';
import { MatTableDataSource } from '@angular/material';
import { ImageGridModel } from '../base/models/image-grid.model';

@Component( {
  selector: 'test',
  templateUrl: './test.component.html',
  styleUrls: [ './test.component.css' ]
} )

export class TestComponent {

  isPoleSearched: boolean = false;

  configurableModel: ImageGridModel[] = [];

  showImageViewer: boolean = false;

  showSearchPanelLoadingBar: boolean = false;

  latitude: number;

  longitude: number;

  progressBarStatus: Array<string> = [];

  downloadedImages: Array<ImageGridModel> = [];

  activeImageInfo: ImageGridModel;

  disableButton = true;

  data: UIConfigurableModel[] = StaticData.mapTextToUIConfigurableModel( StaticData.processingPanel( false ) );

  showImageLoadingBar: boolean = false;

  commentaryMessages: Array<SearchParamsModel> = [];

  commentaryDataSource: MatTableDataSource<any>;

  constructor( private ws: WebSocketService, private apiService: ApiService, private restService: RestService ) { }

  ngOnInit() {
    this.ws.createSocket( 'ws://localhost:7604' ).subscribe( ( data ) => {
      let params = ReusableMethodsModel.convertStringIntoObject( data );
      if ( params && params.key && StaticData.processingPanel( true ).includes( params.key ) ) {
        this.showImageLoadingBar = true;
        this.restService.createSnackBar( params.key, "close", 5000 );
        if ( this.progressBarStatus.includes( params.key ) ) {
          this.progressBarStatus = this.progressBarStatus.slice( 0, this.progressBarStatus.indexOf( params.key ) );
        }
        if ( params[ 'in_file_id' ] && params.key.toLowerCase() != 'found' ) {
          params.found = false;
          this.fetchLiveImage( params )
        }
        this.checkIfFound( params.key );
        if ( params.key && params.key.toLowerCase() === 'found' ) {
          params.found = true;
          this.fetchLiveImage( params )
        }
        this.progressBarStatus.push( params.key );
      } else if ( params && params.key == 'commentary' ) {
        params.message = ` ${ new Date().toLocaleTimeString() }  -  ${ params.message }`;
        this.commentaryMessages = [ ...this.commentaryMessages, params ];
        this.commentaryDataSource = new MatTableDataSource( this.commentaryMessages )
      }
    } );
  }

  onDetectChange() {
    this.showSearchPanelLoadingBar = true;
    setTimeout( () => {
      this.isPoleSearched = true;
      this.showSearchPanelLoadingBar = false;
      this.apiService.searchPoles( new SearchParamsModel( { gridRef: this.latitude } ) )
        .subscribe( ( data ) => {
          console.log( data )
        } )
    }, 3000 );
  }

  checkIfFound( data ) {
    if ( data.toLowerCase() == 'found' ) {
      this.showImageLoadingBar = false;
      this.data = [ ...StaticData.mapTextToUIConfigurableModel( StaticData.processingPanel( false ) ), new UIConfigurableModel( 'Found' ) ]
      // this.restService.createSnackBar("Image Detected","close", 5000);
    } else if ( data.toLowerCase() == 'not found' ) {
      this.showImageLoadingBar = false;
      this.data = [ ...StaticData.mapTextToUIConfigurableModel( StaticData.processingPanel( false ) ), new UIConfigurableModel( 'Not Found' ) ]
    }
  }


  fetchLiveImage( params: SearchParamsModel ) {
    let searchParam: SearchParamsModel = new SearchParamsModel();
    searchParam.rqstId = params[ 'rqst_id' ];
    searchParam.inImgId = params.found ? params[ 'out_file_id' ] : params[ 'in_file_id' ];
    if(params.found) {
      searchParam.inFileId = params[ 'in_file_id' ];
    }
    this.apiService.getImage( searchParam ).subscribe( ( data: any ) => {
      let imageGrid: ImageGridModel = new ImageGridModel( data );
      this.downloadedImages = [ ...this.downloadedImages, ImageHelper.processEncodedBase64ToImage( imageGrid ) ]
    } )
  }
}
