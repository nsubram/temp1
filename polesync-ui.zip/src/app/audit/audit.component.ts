import { Component, ViewChild } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { UIConfigurableModel } from '../base/models/ui-configurable.model';
import { ApiService } from '../base/services/api.service';
import { SearchParamsModel } from '../base/models/search-params.model';
import { ImageHelper } from '../base/helpers/image-helper';
import { AuditModel } from '../base/models/audit.model';
import { AuditParamsModel } from '../base/models/audit-params.model';
import { ImageGridModel } from '../base/models/image-grid.model';

@Component( {
  selector: 'audit',
  templateUrl: './audit.component.html',
  styleUrls: [ './audit.component.css' ]
} )

export class AuditComponent {

  displayedColumns = [];

  paramsDisplayedColumns = [];

  dataSource: MatTableDataSource<AuditModel>;

  paramsDataSource: MatTableDataSource<any>;

  totalLength = 0;

  functionalFilterData: any = null;

  clonedFilterData: any = null;

  paramsId: number = null;

  page: Object;
  @ViewChild( MatSort ) sort: MatSort;

  configurableModel: ImageGridModel[] = [];
  activeImageInfo: ImageGridModel;
  showImageViewer: boolean = false;
  showGrid: boolean = false;
  showParams: boolean = false;
  selectedAudit: AuditModel;

  constructor( private apiService: ApiService ) { }

  async onGridSelect( element: AuditModel ) {
    this.showParams = false;
    if ( element && element.gridRef ) {
      this.showGrid = true;
      let searchParams: SearchParamsModel = new SearchParamsModel();
      searchParams.rqstId = element.rqstId;
      searchParams.datasource = element.datasource
      await this.apiService.getImageForGridReference( searchParams ).toPromise().then( ( data: Array<any> ) => {
        if ( data && data.length > 0 ) {
          data = data.map( ( obj: any ) => new ImageGridModel( obj ) );
          this.configurableModel = data.map( ( obj: ImageGridModel ) => ImageHelper.processEncodedBase64ToImage( obj ) );
        }
      }, ( error ) => {
        console.log( error )
      } )
    }
  }

  async getFunctionalParamsData( element: AuditModel ) {
    this.showParams = true;
    this.showGrid = false;
    this.selectedAudit = element;
    this.paramsId = parseInt( element.rqstId );
  }

  getServerCall() {
    if ( !this.clonedFilterData || this.clonedFilterData != this.functionalFilterData ) {
      this.clonedFilterData = this.functionalFilterData;
    }
  }

}
