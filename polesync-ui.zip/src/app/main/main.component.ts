import { Component } from '@angular/core';
import { UIConfigurableModel } from '../base/models/ui-configurable.model';


@Component({
  selector: 'main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})

export class MainComponent {
  data = [ 
    new UIConfigurableModel('Audit',false,'/main/audit'),
    new UIConfigurableModel('Test',false,'/main/test')
  ];
}
