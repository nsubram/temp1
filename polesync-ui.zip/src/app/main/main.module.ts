import { NgModule } from '@angular/core';
import { BaseModule } from '../base/base.module';
import { MaterialModule } from '../base/material.module';
import { MainComponent } from './main.component';
import { AuditComponent } from '../audit/audit.component'
import {Routes, RouterModule} from '@angular/router';

import { TestComponent } from '../test/test.component';
import { LoginGuard } from '../base/services/guards/login-guard.service';

const routes:Routes = [
  {
    path:'main', component: MainComponent, canActivate:[LoginGuard],
    children: [
      {path:'', redirectTo:'/main/test', pathMatch:'full' },
      {path:'test', component: TestComponent, canActivate:[LoginGuard] },
      {path:'audit', component: AuditComponent, canActivate:[LoginGuard] }
    ]
  }
]

 const declarations = [ MainComponent, TestComponent, AuditComponent];
 const modules = [ BaseModule, MaterialModule];

@NgModule({
  declarations: [...declarations],
  imports: [...modules, RouterModule.forChild(routes)],
  exports: [RouterModule,...declarations,...modules],
  providers: [],
})

export class MainModule { }
