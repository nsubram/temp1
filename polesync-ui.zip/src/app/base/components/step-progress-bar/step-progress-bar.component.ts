/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Progress Bar Component.
 */

import { Input, Component, Output, EventEmitter } from "@angular/core";
import { UIConfigurableModel } from "../../models/ui-configurable.model";

@Component({
    selector:'step-progress-bar',
    styleUrls: ['./step-progress-bar.component.css'],
    templateUrl: 'step-progress-bar.component.html'
})

export class StepProgressBarComponent {
    
    @Input() 
    data: Array<UIConfigurableModel> = [];

    @Input()
    progressBarStatus: Array<string> = [];

    setActiveClassToProgressBar( data ) {
      let text = data.toLowerCase();

      if( this.progressBarStatus && this.progressBarStatus.length > 0 ) {
          return this.progressBarStatus.includes(data) ? 'active' : null;
      } else {
          return null;
      }

    }
    
}