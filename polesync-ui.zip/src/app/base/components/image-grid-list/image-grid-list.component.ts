/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Image grid list component.
 */

import { Component, Output, EventEmitter, Input, SimpleChanges } from '@angular/core';
import { UIConfigurableModel } from '../../models/ui-configurable.model';
import { DomSanitizerService } from '../../services/base/dom-sanitizer.service';
import { ImageGridModel } from '../../models/image-grid.model';

@Component( {
  selector: 'image-grid-list',
  templateUrl: './image-grid-list.component.html',
  styleUrls: [ './image-grid-list.component.css' ]
} )

export class ImageGridListComponent {

  @Input()
  configurableModel: ImageGridModel[] = [];

  @Output()
  configurableModelChange: EventEmitter<ImageGridModel[]> = new EventEmitter();

  showImageViewer = false;

  @Output()
  showImageViewerChange: EventEmitter<boolean> = new EventEmitter();

  @Output()
  activeImageInfo: EventEmitter<any> = new EventEmitter();

  @Input()
  rowHeight: string = '2:1';

  ngOnChanges( changes: SimpleChanges ) {
    if ( changes && changes.configurableModel && changes.configurableModel.currentValue && changes.configurableModel.currentValue.length > 0 ) {
      console.log( 'changed' )
    }
  }

  constructor( private domSanitizerService: DomSanitizerService ) { }

  afterImageSelection( showImage: boolean = true, configModel: ImageGridModel = new ImageGridModel() ) {
    if ( showImage ) {
      this.showImageViewer = true;
      this.showImageViewerChange.emit( this.showImageViewer );
      this.configurableModelChange.emit( this.configurableModel );
    } else {
      this.activeImageInfo.emit( configModel ? configModel : {} );
    }
  }

  resetConfigModel() {
    this.configurableModel = this.configurableModel.map( ( config: ImageGridModel ) => {
      config.active = false;
      return config;
    } )
  }

  getDomSafeImageUrl( configModel: any ) {
    return this.domSanitizerService.getDomSafeImageUrl( configModel )
  }

}
