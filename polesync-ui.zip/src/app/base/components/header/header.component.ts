/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Headers component.
 */

import { Input, Component } from "@angular/core";
import { UIConfigurableModel } from "../../models/ui-configurable.model";

@Component({
    selector:'header',
    styleUrls: ['./header.component.css'],
    templateUrl: 'header.component.html'
})

export class HeaderComponent {
    
    @Input() 
    data: Array<UIConfigurableModel> = [];

    @Input()
    logoImageLink: string = null;

    @Input()
    title:string = null;
}