/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Grid Reference Component.
 */

import { Input, Component, TemplateRef, Output, EventEmitter } from "@angular/core";

@Component({
    selector:'search-panel',
    styleUrls: ['./search-panel.component.css'],
    templateUrl: 'search-panel.component.html'
})

export class SearchPanelComponent {
    
    @Input() 
    template: TemplateRef<any> = null

    @Input()
    disableButton:boolean = false;

    @Output()
    onDetectChange: EventEmitter<any> = new EventEmitter();

    @Input()
    latitude: number;

    @Input()
    longitude: number;

    @Output()
    latitudeChange: EventEmitter<number> = new EventEmitter();

    @Output()
    longitudeChange: EventEmitter<number> = new EventEmitter();

    @Input()
    width: string = '100';

    @Input()
    marginRight: string = null

    detectPoles() {
        this.onDetectChange.emit();
        this.longitudeChange.emit(this.longitude);
        this.latitudeChange.emit(this.latitude);
    }
    
}