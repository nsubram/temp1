/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Snackbar Component (Refer RestService inside service folder for further instructions).
 */

import { Component, Inject } from  '@angular/core';
import { MatSnackBarRef, MAT_SNACK_BAR_DATA } from '@angular/material';

@Component({
  selector: 'snack-bar',
  templateUrl:'snack-bar.component.html',
  styleUrls:['snack-bar.component.css']
})

export class SnackbarComponent {
  constructor(public snackBarRef: MatSnackBarRef<SnackbarComponent>, @Inject(MAT_SNACK_BAR_DATA) public data: any){}
}