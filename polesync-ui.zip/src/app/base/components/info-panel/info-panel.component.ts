/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Info Panel component.
 */

import { Component, Input, SimpleChanges } from '@angular/core';
import { ReusableMethodsModel } from '../../models/reusable-methods.model';
import { ImageGridModel } from '../../models/image-grid.model';

@Component( {
  selector: 'info-panel',
  templateUrl: './info-panel.component.html',
  styleUrls: [ './info-panel.component.css' ]
} )

export class InfoPanelComponent {

  @Input()
  activeImageInfo: ImageGridModel;

  // ngOnChanges(changes: SimpleChanges) {
  //   if( changes && changes.activeImageInfo && changes.activeImageInfo.currentValue.streetViewParameters ) {
  //     let searchParams = ReusableMethodsModel.convertStringIntoObject( changes.activeImageInfo.currentValue.streetViewParameters, ',' );
  //     Object.assign(  this.activeImageInfo, searchParams );
  //   }
  // }

  get checkIfObjectDataPresent() {
    return ReusableMethodsModel.isObjectDataPresent( this.activeImageInfo );
  }

}
