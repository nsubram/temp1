/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Functional table component.
 */

import { Component, ViewChild, Output, EventEmitter, Input, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { ArrayUtils } from '../../models/array-utils';
import { UIConfigurableModel } from '../../models/ui-configurable.model';
import { SearchParamsModel } from '../../models/search-params.model';
import { ApiService } from '../../services/api.service';

@Component( {
  selector: 'functional-table',
  templateUrl: './functional-table.component.html',
  styleUrls: [ './functional-table.component.css' ]
} )

export class FunctionalTableComponent {

  @Input()
  dataSource: MatTableDataSource<any> = new MatTableDataSource();

  @Input()
  displayedColumns = [];

  @Input()
  useDefault = true

  @ViewChild( MatSort )
  sort: MatSort;

  @Output()
  onGridClickChange: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  onParamsClickChange: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  onFilterChange: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  onNoResultFoundChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild( MatPaginator )
  paginator: MatPaginator;

  @Output()
  pageChange: EventEmitter<any> = new EventEmitter<any>();

  @Input()
  pageSizeOptions: Array<number> = [ 10 ] //[ 5, 10, 20 ];

  filterColumn: string = 'gridRef';

  @Input()
  totalLength = 0;

  filterOptions: Array<UIConfigurableModel> = [
    new UIConfigurableModel( 'Grid Reference', null, null, null, null, 'gridRef' ),
    new UIConfigurableModel( 'Request Id', null, null, null, null, 'rqstId' ),
    new UIConfigurableModel( 'Status', null, null, null, null, 'status' )
  ]

  constructor( private apiService: ApiService, private cd: ChangeDetectorRef ) { }

  ngOnChanges( changes: SimpleChanges ) {
    if ( changes && changes.dataSource ) {
      this.dataSource = changes.dataSource.currentValue;
      if ( this.dataSource ) {
        this.dataSource.sort = this.sort;
        // this.dataSource.paginator = this.paginator;
      }
    }
  }

  ngOnInit() {
    if ( this.dataSource ) {
      this.dataSource.sort = this.sort;
    }
  }

  consoleDataSource() {
    console.log( 'dataSource - ', this.dataSource );
  }

  applyFilter( event: KeyboardEvent ) {
    if ( ( event && event.keyCode === 13 ) ) {
      const filterValue = ( event.target as HTMLInputElement ).value;
      this.dataSource.filter = filterValue.trim().toLowerCase();
      let _this = this;
      this.dataSource.filterPredicate = function ( data, filter: string ): boolean {
        return data && data[ _this.filterColumn ] ? data[ _this.filterColumn ].toString().toLowerCase().includes( filter.trim().toLowerCase() ) : false;
      };
      this.onFilterChange.emit( filterValue );
      if ( ArrayUtils.isEmpty( this.dataSource.filteredData ) ) {
        this.onNoResultFoundChange.emit( true );
        let searchParams = new SearchParamsModel();
        searchParams.filterColumn = this.filterColumn;
        searchParams.filterValue = filterValue;
        this.findDataBasedOnColumn( searchParams );
      }
    }
  }

  get filterLabel() {
    return this.filterColumn && this.filterColumn != 'null' && this.filterColumn != undefined ? `Filter on ${ this.filterColumn }` : 'Filter';
  }

  findDataBasedOnColumn( searchParams: SearchParamsModel = new SearchParamsModel() ) {
    this.apiService.findAuditDataBasedOnColumn( searchParams ).subscribe( ( data ) => {
      data = [ ...this.dataSource.data, ...( ArrayUtils.isNotEmpty( data ) ? data : [] ) ];
      this.dataSource = new MatTableDataSource( data );
      this.dataSource.sort = this.sort;
      this.dataSource.filter = searchParams.filterValue;
    } );
  }

}
