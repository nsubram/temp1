/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Functional params table component.
 */


import { Component, ViewChild, Output, EventEmitter, Input, SimpleChanges } from '@angular/core';
import { MatTableDataSource, MatSort } from '@angular/material';
import { ArrayUtils } from '../../models/array-utils';

@Component({
  selector: 'functional-params-table',
  templateUrl: './functional-params-table.component.html',
  styleUrls: ['./functional-params-table.component.css']
})

export class FunctionalParamsTableComponent  {

  @Input()
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  
  @Input()
  displayedColumns = [];

  @ViewChild(MatSort) 
  sort: MatSort;

  @Output()
  onFilterChange: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  onNoResultFoundChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  ngOnChanges(changes: SimpleChanges) {
    if(changes && changes.dataSource) {
      this.dataSource = changes.dataSource.currentValue;
      if(this.dataSource) {
        this.dataSource.sort = this.sort;
      }
    }
  }

  ngOnInit() {
    if ( this.dataSource ) {
      this.dataSource.sort = this.sort;  
    }
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.onFilterChange.emit(filterValue);
    if( ArrayUtils.isEmpty( this.dataSource.filteredData ) ) {
      this.onNoResultFoundChange.emit(true);
    }
  }

}
