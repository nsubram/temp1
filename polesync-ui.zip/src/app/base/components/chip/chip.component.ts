/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Chip Component.
 */

import {Component, Input, SimpleChanges, Output, EventEmitter, ViewChild, ViewChildren, ChangeDetectorRef} from '@angular/core';
import { MatChip } from '@angular/material';
import { ArrayUtils } from '../../models/array-utils';
import { UIConfigurableModel } from '../../models/ui-configurable.model';

@Component({
  selector: 'chip',
  templateUrl: 'chip.component.html',
  styleUrls: ['chip.component.css'],
})
export class ChipComponent {

    @Input()
    data: Array<UIConfigurableModel>;
    
    viewableData: Array<UIConfigurableModel> = [];

    selected: string = null;

    @Input()
    color: string = "primary"

    @Output()
    selectedChange: EventEmitter<string> = new EventEmitter<string>();

    @ViewChildren(MatChip)
    matChips: any;

    private count:number = 0;

    constructor(private cd: ChangeDetectorRef) {}


    ngOnChanges(changes: SimpleChanges) {
      if(changes && changes.data && changes.data.currentValue) {
        if (Array.isArray(changes.data.currentValue)) {
          this.viewableData = changes.data.currentValue;
        } else if(typeof changes.data.currentValue == 'string') {
          this.viewableData = [ new UIConfigurableModel(changes.data.currentValue, null,null,null,null,changes.data.currentValue) ]
        } else if(typeof changes.data.currentValue == 'object') {
          this.viewableData = [ changes.data.currentValue ]
        }
      }
    }

    check(data: any) {
        this.resetSelected(this.matChips._results, data.text);
    }

    ngAfterViewChecked() {
      if( this.matChips && ArrayUtils.isNotEmpty(this.matChips._results) && !this.count ) {
        let reduce = this.matChips._results.map((matChip: MatChip) => matChip.selected).reduce((a,b) => a && b)
        if( !reduce ) {
          this.matChips.first.selected = true;
          let key = ArrayUtils.first(this.viewableData.filter((config: UIConfigurableModel) => config.text === this.matChips.first.value)).key
          this.selected = key;
          this.selectedChange.emit(this.selected);
          this.count = 1;
          this.cd.detectChanges()
        }
      }
    }

    resetSelected(matChipQuery: Array<MatChip>, data: string) {
        if(ArrayUtils.isNotEmpty(matChipQuery)) {
            matChipQuery = matChipQuery.map((matChip: MatChip) => {
                if(data && matChip.value === data) {
                  matChip.selected = true;
                } else {
                  matChip.selected = false;
                }
                return matChip;
            })
        }
    }
}