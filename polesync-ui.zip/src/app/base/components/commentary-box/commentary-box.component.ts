import { Component, Input, ViewChild, SimpleChanges } from "@angular/core";
import { SearchParamsModel } from "../../models/search-params.model";
import { MatTableDataSource, MatPaginator } from "@angular/material";

@Component({
    selector: 'commentary-box',
    templateUrl: 'commentary-box.component.html',
    styleUrls: ['commentary-box.component.css']
})

export class CommentaryBoxComponent {
  @Input()
  commentaryMessages: Array<SearchParamsModel> = [];

  date:Date = new Date();

  @Input()
  dataSource: MatTableDataSource<any> = new MatTableDataSource();
  
  @Input()
  displayedColumns = ['message'];

  @ViewChild(MatPaginator) 
  paginator: MatPaginator;

  ngOnChanges(changes: SimpleChanges) {
    if(changes && changes.dataSource && changes.dataSource.currentValue) {
        this.dataSource.paginator = this.paginator;
    }
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  
}