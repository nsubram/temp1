/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Card Component.
 */


import { Component, Input, EventEmitter, Output } from '@angular/core';
import { UIConfigurableModel } from '../../models/ui-configurable.model';

@Component( {
  selector: 'card',
  templateUrl: './card.component.html',
  styleUrls: [ './card.component.css' ]
} )

export class CardComponent {
  @Input()
  title: string = null;

  @Input()
  subTitle: string = null;

  @Input()
  showLoadingBar: boolean = false;

  @Input()
  loadingBarMode: 'indeterminate' | 'determinate' | 'buffer' | 'query' = 'indeterminate';

  @Input()
  determinateValue: number = 25;

  @Input()
  showClose = false;

  @Input()
  showFullScreen = false;

  @Input()
  showExpandedScreen = false;

  enableFullScreen: boolean = false;

  expandCard: boolean = true;

  @Output()
  onClose: EventEmitter<boolean> = new EventEmitter<boolean>();

}
