/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Reusable Image viewer component.
 */

import { Component, Input, EventEmitter, Output } from '@angular/core';
import { UIConfigurableModel } from '../../models/ui-configurable.model';
import { DomSanitizerService } from '../../services/base/dom-sanitizer.service';
import { ImageGridModel } from '../../models/image-grid.model';

@Component( {
  selector: 'image-viewer',
  templateUrl: './image-viewer.component.html',
  styleUrls: [ './image-viewer.component.css' ]
} )

export class ImageViewerComponent {

  slideIndex = 1;

  @Input()
  configurableModel: ImageGridModel[] = [];

  @Output()
  configurableModelChange: EventEmitter<ImageGridModel[]> = new EventEmitter<ImageGridModel[]>();

  @Output()
  showImageViewerChange: EventEmitter<boolean> = new EventEmitter();

  constructor( private domSanitizerService: DomSanitizerService ) { }

  openModal() {
    document.getElementById( "myModal" ).style.display = "block";
  }

  plusSlides( type: 'prev' | 'next' = 'next' ) {
    let configModel = this.configurableModel.filter( ( config: ImageGridModel ) => config.active )[ 0 ];
    let index = this.configurableModel.indexOf( configModel );
    this.resetConfigModel()
    if ( index > -1 && ( index + 1 ) <= ( this.configurableModel.length - 1 ) && type == 'next' ) {
      this.configurableModel[ index + 1 ].active = true;
    } else if ( index > 0 && index < this.configurableModel.length && type == 'prev' ) {
      this.configurableModel[ index - 1 ].active = true;
    } else if ( ( index + 1 ) > ( this.configurableModel.length - 1 ) && type == 'next' ) {
      this.configurableModel[ 0 ].active = true;
    } else {
      this.configurableModel[ this.configurableModel.length - 1 ].active = true;
    }
  }

  currentSlide( index ) {
    this.resetConfigModel();
    this.configurableModel[ index ].active = true;
  }

  resetConfigModel() {
    this.configurableModel = this.configurableModel.map( ( config: ImageGridModel ) => {
      config.active = false;
      return config;
    } )
    this.configurableModelChange.emit( this.configurableModel );
  }

  getDomSafeImageUrl( configModel: any ) {
    return this.domSanitizerService.getDomSafeImageUrl( configModel )
  }

}
