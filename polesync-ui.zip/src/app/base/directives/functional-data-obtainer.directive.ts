/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Directives to fetch audit (functional) data.
 */

import { Directive, NgZone, Input, SimpleChanges } from '@angular/core';
import { BaseDataObtainer } from '../helpers/base-data-obtainer';
import { SearchParamsModel } from '../models/search-params.model';
import { ApiService } from '../services/api.service';
import { MatTableDataSource, MatPaginator } from '@angular/material';
import { ArrayUtils } from '../models/array-utils';
import { AuditModel } from '../models/audit.model';

@Directive( {
  selector: '[functionalDataObtainer]'
} )

export class FunctionalDataObtainer extends BaseDataObtainer {

  @Input()
  page: Object;

  ngOnChanges( changes: SimpleChanges ) {
    if ( changes && changes.page && changes.page.currentValue ) {
      let searchParams = new SearchParamsModel( changes.page.currentValue )
      this.refreshData( searchParams )
    }
  }

  constructor( protected zone: NgZone, private apiService: ApiService ) {
    super( zone );
  }

  getDataObservable( searchParams: SearchParamsModel ) {
    return this.apiService.getFunctionalUiData( searchParams );
  }

  refreshData( searchParams: SearchParamsModel = new SearchParamsModel() ) {
    super.refreshData( searchParams )
  }

  onAfterUpdateData() {
    if ( this.isDataPresent() ) {
      if ( ArrayUtils.isNotEmpty( this.data.data ) ) {
        this.data.data = this.data.data.map( ( audit: any ) => new AuditModel( audit ) );
        this.dataChange.emit( this.data );
        this.dataSource = new MatTableDataSource( this.data.data );
        this.displayedColumns = Object.keys( ArrayUtils.first( this.data.data ) ).sort();
        this.dataSourceChange.emit( this.dataSource );
        this.totalLength = this.data.totalLength;
        this.totalLengthChange.emit( this.totalLength );
        this.displayedColumnsChange.emit( this.displayedColumns );
      }

    }
  }

}
