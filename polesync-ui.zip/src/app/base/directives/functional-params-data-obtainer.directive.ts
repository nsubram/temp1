/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Directives to fetch audit params(functional params) data.
 */


import { Directive, NgZone, Input } from '@angular/core';
import { BaseDataObtainer } from '../helpers/base-data-obtainer';
import { SearchParamsModel } from '../models/search-params.model';
import { ApiService } from '../services/api.service';
import { MatTableDataSource } from '@angular/material';
import { ArrayUtils } from '../models/array-utils';
import { AuditParamsModel } from '../models/audit-params.model';

@Directive( {
  selector: '[functionalParamsDataObtainer]'
} )

export class FunctionalParamsDataObtainer extends BaseDataObtainer {

  @Input()
  paramsId: number = null;

  @Input()
  paramsDataSource: string = null;

  constructor( protected zone: NgZone, private apiService: ApiService ) {
    super( zone );
  }

  getDataObservable( searchParams: SearchParamsModel ) {
    searchParams.paramId = this.paramsId;
    searchParams.datasource = this.paramsDataSource;
    return this.apiService.getFunctionalParamsData( searchParams );
  }

  onAfterUpdateData() {
    if ( this.isDataPresent() ) {
      this.data = this.data.map( ( obj: any ) => new AuditParamsModel( obj ) );
      this.dataChange.emit( this.data );
      this.dataSource = new MatTableDataSource( this.data );
      this.displayedColumns = Object.keys( ArrayUtils.first( this.data ) );
      this.dataSourceChange.emit( this.dataSource );
      this.displayedColumnsChange.emit( this.displayedColumns );
    }
  }

}
