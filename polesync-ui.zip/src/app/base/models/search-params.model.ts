/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Used for sharing data between models or keeping single model.
 */

export class SearchParamsModel {
    [key: string] : any

    constructor(jsonObj?: {}) {
       if( jsonObj && Object.keys(jsonObj) && Object.keys(jsonObj).length > 0 ) {
         Object.assign(this, jsonObj);
       }
    }
}