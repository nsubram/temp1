/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Utility Model for array methods
 */

export class ArrayUtils {

   static isEmpty(arr: Array<any>) {
     return arr && arr.length < 1;
   }

   static isNotEmpty(arr: Array<any>) {
     return arr && arr.length > 0;
   }

   static first(arr: Array<any>) {
     return ArrayUtils.isNotEmpty(arr) ? arr[0] : null;
   }

   static last(arr: Array<any>) {
     return ArrayUtils.isNotEmpty(arr) ? arr[arr.length - 1] : null;
   }

}
