import { ReusableMethodsModel } from "./reusable-methods.model";

export class AuditModel {

  rqstId: string;
  objType: string;
  gridRef: string;
  latitude: string;
  longitude: string;
  status: string;
  time: string;
  hits: string;
  datasource: string

  constructor( jsonObj?: {} ) {
    if ( jsonObj && ReusableMethodsModel.isObjectDataPresent( jsonObj ) ) {
      Object.assign( this, jsonObj );
    } else {
      this.datasource = this.gridRef = this.hits = this.latitude = this.longitude =
        this.objType = this.rqstId = this.status = this.time = null;
    }
  }
}
