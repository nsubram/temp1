import { ReusableMethodsModel } from "./reusable-methods.model";

export class AuditParamsModel {

  inImgId: string;
  rqstId: string;
  apiRqstId: string;
  pitch: string;
  fov: string;
  heading: string;

  constructor( jsonObj?: {} ) {
    if ( jsonObj && ReusableMethodsModel.isObjectDataPresent( jsonObj ) ) {
      Object.assign( this, jsonObj );
    } else {
      this.inImgId = this.rqstId = this.apiRqstId = this.pitch = this.fov = this.heading = null;
    }
  }
}
