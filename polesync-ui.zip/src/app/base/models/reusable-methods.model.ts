/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Common methods model.
 */

import {ArrayUtils} from './array-utils';
import {SearchParamsModel} from './search-params.model';

export class ReusableMethodsModel {

    static isObjectDataPresent(obj: {}) {
      return obj && Object.keys(obj) && obj && Object.keys(obj).length > 0;
    }

    static convertWebSocketMessageIntoObject(str: string) {
      return str ? str.split(';') : null;
    }

    static convertStringIntoObject(str: string, seperator: string = ";", innerSeperator: string = "=") {
      let paramsModel = new SearchParamsModel();
      if ( str ) {
        let data = str.split(seperator);
        if ( ArrayUtils.isNotEmpty(data) ) {
          data.forEach((eachString: string) => {
            let keyValue = eachString.split(innerSeperator);
            if( ArrayUtils.first(keyValue) && ArrayUtils.last(keyValue)) {
              paramsModel[ ArrayUtils.first(keyValue).trim() ] = ArrayUtils.last(keyValue).trim();
            }
          })
        }
      }
      return paramsModel;
    }

}
