import { ReusableMethodsModel } from "./reusable-methods.model";

export class ImageGridModel {
  rqstId: string;
  apiRqstId: string;
  inImgId: string;
  detection: string;
  datasource: string;
  score: number;
  fov: number;
  pitch: number;
  heading: number;
  active: boolean = false;
  imageUrl: string = null

  constructor( jsonObj?: {} ) {
    if ( ReusableMethodsModel.isObjectDataPresent( jsonObj ) ) {
      Object.assign( this, jsonObj );
    } else {
      this.apiRqstId = this.datasource = this.detection = this.fov = this.heading =
        this.inImgId = this.pitch = this.rqstId = this.score = this.imageUrl = null;
      this.active = false;
    }
  }
}