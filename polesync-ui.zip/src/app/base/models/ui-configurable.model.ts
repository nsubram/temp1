/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Used for sharing data between ui components.
 */

export class UIConfigurableModel {
    text?: string; 
    active?: boolean = false;
    url?: string = null;
    imageUrl?: string = null;
    imageInfo?:Object = null;
    key: string = null;
    

    constructor( ...args: Array<any> ){
        let jsonObj = undefined;
        this.text = jsonObj && jsonObj.text ? jsonObj.text : arguments[0] ? arguments[0] : null;
        this.active = jsonObj && jsonObj.active ? jsonObj.active : arguments[1] ? arguments[1] : false;
        this.url = jsonObj && jsonObj.url ? jsonObj.url : arguments[2] ? arguments[2] : null;
        this.imageUrl = jsonObj && jsonObj.imageUrl ? jsonObj.imageUrl : arguments[3] ? arguments[3] : null;
        this.imageInfo = jsonObj && jsonObj.imageInfo ? jsonObj.imageInfo : arguments[4] ? arguments[4] : null;
        this.key = jsonObj && jsonObj.key ? jsonObj.key : arguments[5] ? arguments[5] : null;
    }


}