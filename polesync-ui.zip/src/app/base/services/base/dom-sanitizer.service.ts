/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Service used for keeping safe urls
 */

import { Injectable } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';

@Injectable()

export class DomSanitizerService {

  constructor( private domSanitizer: DomSanitizer ) { }

  getDomSafeImageUrl( configModel: any ) {
    if ( configModel && configModel.imageUrl ) {
      let safeUrl: SafeUrl = this.domSanitizer.bypassSecurityTrustResourceUrl( configModel.imageUrl );
      return safeUrl;
    } else {
      return null;
    }
  }

}
