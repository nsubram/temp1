/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Service used for common rest calls and more
 */

import { Injectable} from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { MatSnackBar} from '@angular/material';
import { SnackbarComponent } from '../../components/snackbar/snack-bar.component';
import {StaticData} from '../../helpers/static-data'
import { Observer } from 'rxjs/Observer';


@Injectable()

export class RestService {
    constructor(private http:HttpClient, private snackBarService: MatSnackBar) {}

    get(url: string, options?: { params?: HttpParams, headers?: HttpHeaders}) {
        return this.http.get(url, options);
    }

    jsonPost(url: string, body?:any, options?: { params?: HttpParams, headers?: HttpHeaders}){
      return this.http.post( url,body,options);
    }

    jsonPut(url: string, body?:any, options?: { params?: HttpParams, headers?: HttpHeaders}){
        return this.http.put( url,body,options);
    }

    jsonPatch(url: string, body?:any, options?: { params?: HttpParams, headers?: HttpHeaders}){
        return this.http.patch( url,body,options);
    }

    delete(url: string, options: { params?: HttpParams, headers?: HttpHeaders}) {
        return this.http.delete(url, options);
    }

    createSnackBar(message: string, action: string = "close", durationMS: number = 2000, cssClass: string = "success", icon?: string){
        this.snackBarService.openFromComponent(SnackbarComponent, {
            data: {
                message: message,
                icon: icon ? icon : 'info',
                action: action,
                class: cssClass
            },
            duration: durationMS,
            verticalPosition: 'top',
            horizontalPosition: 'right'
        })

    }

    createNotifySnackbar(key: string, action: string = "close", durationMS: number = 2000) {
        let message = ( message ) => (StaticData.poleSyncStaticMessages[message]);

        let observer: Observer<any> = {
            next: (data) => {
                this.createSnackBar(message('success')[key] ? message('success')[key] : key, action, durationMS, "success");
            }, error: (error) => {
                this.createSnackBar(message('error')[key] ? message('error')[key] : key, action, durationMS, "error");
            }, complete: () => {

            }
        };

        return observer;
    }



}