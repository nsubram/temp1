import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { SearchParamsModel } from '../models/search-params.model';
import { RestService } from './base/rest.service';
import { tap } from 'rxjs/operators';


@Injectable()
export class ApiService {

	port: any = {};

	constructor( private restService: RestService ) { }

	searchPoles( searchParam: SearchParamsModel ) {
		return this.restService.jsonPost( `${ environment.domainUrl }/poles/${searchParam.gridRef}`, searchParam );
	}

    getBackendPortNumber() {
		return this.restService.get( encodeURI( `${ environment.domainUrl }/configurations/appservice` ) );
	}

	getImage( searchParam: SearchParamsModel ) {
		let uri =  `${ environment.domainUrl }/requests/${ searchParam.rqstId }/data/${ searchParam.inImgId }`;
		if(searchParam.found) {
		  uri = encodeURI(`uri?in_file_id = ${searchParam.inFileId}`);
		}
		return this.restService.get( uri );
		
	}

	getImageForGridReference( searchParam: SearchParamsModel ) {
		return this.restService.get( encodeURI( `${ environment.domainUrl }/requests/${ searchParam.rqstId }/data?datasource=${ searchParam.datasource }` ) );
	}

	getFunctionalUiData( searchParam: SearchParamsModel = new SearchParamsModel() ) {
		return this.restService.get( `${ environment.domainUrl }/requests?pagenum=${ searchParam.pageIndex > -1 ? searchParam.pageIndex : 0 }&pagesize=${ searchParam.pageSize ? searchParam.pageSize : 10 }` );
	}

	getFunctionalParamsData( searchParam: SearchParamsModel = new SearchParamsModel() ) {
		return this.restService.get( `${ environment.domainUrl }/requests/${ searchParam.paramId }/params?datasource=${ searchParam.datasource }` );
	}

	login( searchParam: SearchParamsModel = new SearchParamsModel() ) {
		return this.restService.jsonPost( `${ environment.domainUrl}/login`, searchParam )
			.pipe( tap( this.restService.createNotifySnackbar( 'login' ) ) );
	}

	findAuditDataBasedOnColumn( searchParam: SearchParamsModel = new SearchParamsModel() ) {
		return this.restService.get( encodeURI( `${ environment.domainUrl }/requests/search?${ searchParam.filterColumn }=${ searchParam.filterValue }` ) )
			.pipe( tap( this.restService.createNotifySnackbar( 'find-audit-data' ) ) );
	}
}
