/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Service used for intercepting http calls
 */

import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

@Injectable()
export class HttpInterceptorService implements HttpInterceptor {
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    let request = req.clone({
        headers: new HttpHeaders().append('Access-Control-Allow-Origin','*')
    });

    return next.handle(request);
  }
}