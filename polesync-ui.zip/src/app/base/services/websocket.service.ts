/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Service used for Websocket connection
 */

import { Injectable} from '@angular/core'
import { Observable } from "rxjs/Observable";
// import * as io from 'socket.io-client';

@Injectable()

export class WebSocketService {
    ws: WebSocket;

    // private socket: SocketIOClient.Socket;

    initializeSocket(url: string) {
    //   this.socket = io(url,
    //     {
    //     forceJSONP: true
    //   }

    //   );
      this.createSocket(url)
    }

    sendMessage(msg: any) {
        // this.socket.emit('sendMessage', { message: msg });
        this.ws.send(msg)
    }

    // HANDLER
    // onNewMessage() {
    //     return Observable.create(observer => {
    //     this.socket.on('newMessage', msg => {
    //         observer.next(msg);
    //     });
    //     });
    // }

    createSocket(url: string): Observable<string> {
        this.ws = new WebSocket(url);
        return new Observable(observer => {
            this.ws.onmessage = (event) => observer.next(event.data);
            this.ws.onerror = (event) => observer.error(event);
            this.ws.onclose = (event) => observer.complete();
        })
    }

}
