/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 * Extend this class to use reusable method with network call
 */


import { NgZone, Input, Output, EventEmitter } from "@angular/core";
import { SearchParamsModel } from "../models/search-params.model";
import { Observable } from "rxjs/Observable";
import { ArrayUtils } from "../models/array-utils";
import { MatTableDataSource } from "@angular/material";
import { ReusableMethodsModel } from "../models/reusable-methods.model";

export abstract class BaseDataObtainer {
  refreshOnInit: boolean = true;
  data: any;
  isLoading: boolean = false;

  @Input()
  dataSource: MatTableDataSource<any> = new MatTableDataSource();

  @Output()
  dataSourceChange: EventEmitter<MatTableDataSource<any>> = new EventEmitter<MatTableDataSource<any>>();

  @Output()
  displayedColumnsChange: EventEmitter<Array<string>> = new EventEmitter<Array<string>>();

  @Input()
  totalLength: number = 0;

  @Output()
  totalLengthChange: EventEmitter<number> = new EventEmitter<number>();

  @Input()
  displayedColumns: Array<string> = [];

  @Output()
  dataChange: EventEmitter<Array<any>> = new EventEmitter<Array<any>>();

  constructor( protected zone: NgZone ) { }

  ngOnInit() {
    if ( this.refreshOnInit ) {
      this.zone.run( () => {
        this.refreshData();
      } );
    }
  }

  refreshData( searchParams: SearchParamsModel = new SearchParamsModel() ) {
    this.onBeforeUpdateData();
    this.isLoading = true;
    this.getDataObservable( searchParams ).subscribe( ( data: any ) => {
      this.data = data;
      this.isLoading = false
      this.onAfterUpdateData( data );
    }, ( err: any ) => {
      this.isLoading = false;
      this.onError();
    }, () => {
      this.onComplete();
    } )
  }

  isDataPresent() {
    if ( Array.isArray( this.data ) ) {
      return ArrayUtils.isNotEmpty( this.data );
    } else if ( typeof this.data == 'object' ) {
      return ReusableMethodsModel.isObjectDataPresent( this.data );
    }
  }

  abstract getDataObservable( searchParams: SearchParamsModel ): Observable<any>;
  onBeforeUpdateData() { }
  onAfterUpdateData( data: any ) { }
  onError() { }
  onComplete() { }
}