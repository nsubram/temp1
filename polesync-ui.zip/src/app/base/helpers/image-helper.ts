/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 * Helper model to convert base64 image into UIConfigurable model
 */

import { UIConfigurableModel } from "../models/ui-configurable.model"
import { ImageGridModel } from "../models/image-grid.model";

export class ImageHelper {

  static processEncodedBase64ToImage( imageGrid: ImageGridModel ): ImageGridModel {
    if ( imageGrid && imageGrid.imageUrl ) {
      imageGrid.imageUrl = `data:image/${ imageGrid.inImgId.split( '.' )[ imageGrid.inImgId.split( '.' ).length - 1 ] };base64,${ imageGrid.imageUrl }`;
      return imageGrid;
    }
  }

}



