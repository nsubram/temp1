/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 * Use to add static data inside model
 */


import { UIConfigurableModel } from "../models/ui-configurable.model";

export class StaticData {

  static processingPanel = ( addFoundInProcessingPanel = true ) => [ 'Request Recieved', 'Converting Grid Reference', 'Reading Configuration', 'Downloading Image',
    'Processing', 'Check Pole Found', ...StaticData.useFoundOrNot( addFoundInProcessingPanel )
  ];

  static mapTextToUIConfigurableModel( textArray: Array<string> = StaticData.processingPanel() ) {
    if ( textArray && textArray.length > 0 ) {
      return textArray.map( ( data: string ) => new UIConfigurableModel( data ) );
    } else {
      return [];
    }
  }

  static useFoundOrNot( addFoundInProcessingPanel = true ) {
    if ( addFoundInProcessingPanel ) {
      return [ 'Found', 'Not Found' ]
    } else {
      return [];
    }
  }

  static poleSyncStaticMessages = {
    success: {
      'found': 'Image Found',
      'login': 'Successfully logged In',
      'find-audit-data': 'Audit Data Sucessfully fetched'
    },
    error: {
      'not-found': 'Failed to Find Image',
      'login': 'Something went wrong',
      'find-audit-data': 'Failed to Fetch Audit Data'
    }
  }

}

