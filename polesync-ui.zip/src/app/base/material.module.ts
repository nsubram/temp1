/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Common Module for material design
 */


import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatInputModule, MatFormFieldModule, MatSliderModule, MatButtonModule, MatGridListModule, MatCardModule,
  MatProgressBarModule, MatTableModule, MatSortModule, MatIconModule, MatSnackBarModule, MatChipsModule, MatPaginatorModule, MatListModule} from '@angular/material';

const importsAndExports = [BrowserAnimationsModule, FormsModule ,MatInputModule, 
    MatFormFieldModule,MatSliderModule, MatButtonModule, MatGridListModule, MatCardModule, 
    MatProgressBarModule, MatTableModule, MatSortModule, MatIconModule, MatSnackBarModule, MatChipsModule,
     MatPaginatorModule, MatListModule];

@NgModule({
    declarations: [],
    imports: [...importsAndExports],
    exports: [...importsAndExports]
})

export class MaterialModule {}