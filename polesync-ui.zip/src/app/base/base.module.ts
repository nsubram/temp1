/**
 * @author Shashikant Mittapelli(sm0c83832@techmahindra.com)
 * 
 *  Modules for base components
 */

import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { StepProgressBarComponent } from './components/step-progress-bar/step-progress-bar.component';
import { HeaderComponent } from './components/header/header.component';
import { SearchPanelComponent } from './components/search-panel/search-panel.component';
import { MaterialModule } from './material.module';
import { ImageGridListComponent } from './components/image-grid-list/image-grid-list.component';
import { ImageViewerComponent } from './components/image-viewer/image-viewer.component';
import { CardComponent } from './components/card/card.component';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { HttpInterceptorService } from './services/http-interceptor.service';
import { WebSocketService } from './services/websocket.service';
import { ApiService } from './services/api.service';
import { DraggableDirective } from './directives/draggable.directive';
import { InfoPanelComponent } from './components/info-panel/info-panel.component';
import { FunctionalTableComponent } from './components/functional-table/functional-table.component';
import { SnackbarComponent } from './components/snackbar/snack-bar.component';
import { RestService } from './services/base/rest.service';
import { DomSanitizerService } from './services/base/dom-sanitizer.service';
import { FunctionalDataObtainer } from './directives/functional-data-obtainer.directive';
import { FunctionalParamsTableComponent } from './components/functional-params-table/functional-params-table.component';
import { FunctionalParamsDataObtainer } from './directives/functional-params-data-obtainer.directive';
import { RouterModule } from '@angular/router';
import { ChipComponent } from './components/chip/chip.component';
import { LoginGuard } from './services/guards/login-guard.service';
import { CommentaryBoxComponent } from './components/commentary-box/commentary-box.component';

const declarationComponents = [ StepProgressBarComponent,  HeaderComponent, SearchPanelComponent,
    ImageGridListComponent, ImageViewerComponent, CardComponent, DraggableDirective, InfoPanelComponent,
    FunctionalTableComponent, SnackbarComponent, FunctionalDataObtainer, FunctionalParamsTableComponent,
    FunctionalParamsDataObtainer, ChipComponent, CommentaryBoxComponent ];
    
const modules = [CommonModule, MaterialModule, HttpClientModule, CommonModule, BrowserModule, RouterModule];
@NgModule({
    declarations: [...declarationComponents],
    imports: [ ...modules ],
    exports: [...declarationComponents, ...modules ],
    providers: [ RestService, { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true },
        ApiService,WebSocketService, DomSanitizerService, LoginGuard
    ],
    entryComponents: [SnackbarComponent]
})

export class BaseModule {}
