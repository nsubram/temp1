import { Component, NgZone, Input, TemplateRef } from '@angular/core';
import { BaseDataObtainer } from '../base/helpers/base-data-obtainer';
import { SearchParamsModel } from '../base/models/search-params.model';
import { ApiService } from '../base/services/api.service';
import { Router } from '@angular/router';


@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent extends BaseDataObtainer  {
    userName: string;

    hide = true;

    password: string;

    @Input()
    width: string = '100';

    @Input()
    marginRight: string = null;

    @Input()
    template: TemplateRef<any>; 

    constructor(protected zone: NgZone, private apiService: ApiService, private router:Router) {
        super(zone);
        this.refreshOnInit = false;
    }

    getDataObservable(searchParams: SearchParamsModel) {
      searchParams.userName = this.userName;
      searchParams.password = this.password;
      return this.apiService.login(searchParams)
    }

    onAfterUpdateData() {
      if(this.isDataPresent) {
        localStorage.setItem('jwt', this.data.jwt);
        this.router.navigateByUrl('/main');
      }
    }

}

