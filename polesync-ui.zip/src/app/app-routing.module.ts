import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {Routes, RouterModule} from '@angular/router';
import { LoginComponent } from './login/login.component';
import { MainModule } from './main/main.module';
import { BrowserModule } from '@angular/platform-browser';

 const routes:Routes = [
    { path: 'login', component: LoginComponent, pathMatch:'prefix'},
    { path: '**', redirectTo:'/login' },
 ]


@NgModule({
  declarations: [ LoginComponent ],
  imports: [BrowserModule,CommonModule, MainModule, RouterModule.forRoot(routes)],
  exports: [LoginComponent, RouterModule, MainModule],
  providers: [],
})

export class AppRoutingModule { }
